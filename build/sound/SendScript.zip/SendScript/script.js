const fs = require("fs/promises");
const https = require("https");
const { PublicKey } = require("@solana/web3.js");

const RPC_URL = "https://ssc-dao.genesysgo.net/";

async function fetch(url, options = {}){
	return new Promise((resolve, reject) => {
		let req = https.request(url, options, res => {
			let data = [];
			res.on("data", d => data.push(d));
			res.on("end", e => {
				let rawData = Buffer.concat(data).toString();
				resolve({
					headers: res.headers,
					status: res.statusCode,
					url,
					text: async () => rawData,
					json: async () => JSON.parse(rawData)
				})
			});
		});

		req.on("error", reject);

		let body = options.body;
		if(typeof body != "string")
			body = JSON.stringify(body);
		if(body && options.method != "GET" && options.method != "HEAD")
			req.write(body);
		
		req.end();
	});
}

async function rpcCall(method, params){
	let response = await fetch(RPC_URL, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			id: "0",
			jsonrpc: "2.0",
			method,
			params
		})
	});
	let json = await response.json();
	
	if(Math.floor(response.status/100) != 2)
		throw new Error(JSON.stringify(json.error, null, 4));
	
	return json.result;
}

async function getTokenAddressesInWallet(walletAddress){
	let response = await rpcCall(
		"getTokenAccountsByOwner",
		[
			walletAddress,
			{ programId: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" },
			{ encoding: "jsonParsed" }
		]
	).then(e => e.value);
	
	return response
		.map(e => e.account.data.parsed.info)
		.filter(e => parseInt(e.tokenAmount.amount) > 0);
}

async function getCandyMachineMints(candyMachineAddress){
	let response = await rpcCall(
		"getProgramAccounts",
		[
			"metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s",
			{
				encoding: "base64",
				dataSlice: { offset: 33, length: 32 },
				filters: [
					{
						memcmp: {
							offset: 326,
							bytes: candyMachineAddress
						}
					}
				]
			}
		]
	);
	
	return response.map(
		({account: {data}}) => new PublicKey(Buffer.from(data[0], "base64")).toBase58()
	);
}

async function getCurrentOwner(mintAddress){
	let largestAccounts = await rpcCall(
		"getTokenLargestAccounts",
		[mintAddress]
	).then(e => e.value);
	
	let tokenAccount = null;
	for(let account of largestAccounts)
		if(account.amount == "1"){
			tokenAccount = account.address;
			break;
		}
	if(!tokenAccount)
		throw new Error(`Could not get current owner for ${mintAddress}`);
	let tokenAccountInfo = await getAccountInfo(tokenAccount);
	
	return tokenAccountInfo.info.owner;
}

async function getTransactionHistory(mintAddress){
	return rpcCall("getSignaturesForAddress", [mintAddress]);
}

async function getTransaction(transactionId){
	return rpcCall("getTransaction", [transactionId]);
}

async function getAccountInfo(address){
	return rpcCall("getAccountInfo", [address, { encoding: "jsonParsed" }])
		.then(e => e.value.data.parsed);
}

function transferToken(token, address){
	console.log(`spl-token transfer "${token}" 1 "${address}" --fund-recipient --allow-unfunded-recipient --no-wait`);
}

async function main(){
	const batchSize = 50;
	const maxRetries = 10;
	
	const walletAddress = "8dMifT71PaNMmsXhTQ4c6TYf9Krcp1wVaKtZgLufWg64";
	const candyMachineAddresses = [
		// "3ibFDnnRBUyt7Kiuq4B6vQaTGKyhVkfWDev4Vc8h3i1i"
	];

	let tokens = await getTokenAddressesInWallet(walletAddress);
	tokens.forEach(t => console.log(t.mint));
	
	let mints = [];
	// mints = JSON.parse(await fs.readFile("mints.json"));
	for(let candyMachineAddress of candyMachineAddresses)
		mints = mints.concat(await getCandyMachineMints(candyMachineAddress));
	
	let owners = [];
	// owners = JSON.parse(await fs.readFile("owners.json"));
	// let retryCount = 0;
	// for(let i = 0; i < mints.length;){
		// console.warn(`Running: ${i} to ${i + batchSize}`)
		// let batch = [];
		// for(let j = 0; j < batchSize && i < mints.length; i++, j++)
			// batch.push(getCurrentOwner(mints[i]));
		// try{
			// owners = owners.concat(await Promise.all(batch));
			// retryCount = 0;
		// }
		// catch(e){
			// console.warn(`Failed: ${e.message}`);
			// if(retryCount < maxRetries){
				// i -= batch.length;
				// retryCount++;
				// console.warn(`Retrying: ${i} to ${i + batchSize}`);
			// }
			// else{
				// console.error("Max retry count exceeded, exiting");
				// break;
			// }
		// }
	// }
	
	// await fs.writeFile("owners.json", JSON.stringify(owners, null, 4));
	
	let ownerCounts = {};
	for(let owner of owners){
		if(!(owner in ownerCounts))
			ownerCounts[owner] = 0;
		ownerCounts[owner]++;
	}
	
	// console.log(ownerCounts);
	
	// let tokenIndex = 0;
	// for(let [owner, count] of Object.entries(ownerCounts))
		// for(let i = 0; i < count; i++)
			// transferToken(tokens[tokenIndex++].mint, owner);
}

if(require.main)
	main().catch(console.error);