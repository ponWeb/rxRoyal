import {
  Connection,
  Transaction,
  SystemProgram,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
} from "@solana/web3.js";

import * as list from "./newList.json";
// aici modifica cat o sa fie payout-ul per nft
const payoutSum = 0.044;
const feeSecret = [
  228, 176, 6, 122, 178, 110, 195, 33, 219, 244, 162, 244, 44, 177, 205, 75,
  239, 165, 167, 55, 172, 240, 215, 173, 18, 57, 69, 193, 210, 136, 17, 86, 250,
  255, 30, 123, 204, 54, 68, 1, 85, 71, 223, 18, 111, 117, 108, 226, 15, 140,
  251, 4, 187, 208, 117, 100, 94, 102, 244, 187, 106, 122, 234, 32,
];
const feeAccount = Keypair.fromSecretKey(Uint8Array.from(feeSecret));
const CONNECTION = new Connection(
  "https://floral-fragrant-dew.solana-mainnet.quiknode.pro/a283c07ef8da1becc2b27461514aed301e81ee60/"
);

const keys = Object.keys(list.default);

const createAndSendTransactionx = async (amount, provider) => {
  let sendValue = LAMPORTS_PER_SOL * amount;

  const instructions = [
    SystemProgram.transfer({
      fromPubkey: feeAccount.publicKey,
      toPubkey: provider,
      lamports: sendValue,
    }),
  ];

  let transaction = new Transaction().add(...instructions);

  transaction.feePayer = feeAccount.publicKey;

  transaction.recentBlockhash = (
    await CONNECTION.getRecentBlockhash()
  ).blockhash;

  try {
    const signature = await CONNECTION.sendTransaction(transaction, [
      feeAccount,
    ]);
    await CONNECTION.confirmTransaction(signature, "confirmed");
    console.log("OK");
  } catch (err) {
    console.log("Transaction failed for ", provider.toString());
  }
};

for (const k in keys) {
  const pbk = new PublicKey(keys[k]);
  const amount = payoutSum * list.default[keys[k]].amount;
  await createAndSendTransactionx(amount, pbk);
}